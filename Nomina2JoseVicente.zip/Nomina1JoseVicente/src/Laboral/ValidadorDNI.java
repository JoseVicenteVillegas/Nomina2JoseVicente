package Laboral;
/**
 * Clase para que el dni que pongamos en el main sea valido o no
 * @author estudiante
 *
 */
public class ValidadorDNI {
	/**
	 * Constructor boolean con parametros
	 * @param dni DNI de la Persona
	 * @return
	 */
	public static boolean validar(String dni) {
		
		String letraMayuscula = "";
		//Hacemos que los caracteres no sean mayores a 9 
		if(dni.length() != 9 || Character.isLetter(dni.charAt(8)) == false) {
			return false;
		}
		
		letraMayuscula = (dni.substring(8)).toUpperCase();
		
		if(soloNumeros(dni) == true && letraDNI(dni).equalsIgnoreCase(letraMayuscula)) {
			return true;
		}
		
		return false;
	}
	/**
	 * Constructor boolean con parametros
	 * @param dni DNI de la Persona
	 * @return
	 */
	private static boolean soloNumeros(String dni) {
		
		int i, j = 0;
		String numero = "";
		String miDNI = "";
		String [] unoNueve = {"0","1","2","3","4","5","6","7","8","9"};
		
		for(i = 0; i < dni.length() -1; i++) {
			numero = dni.substring(i, i+1);
			
			for(j = 0; j < unoNueve.length; j++) {
				if(numero.equals(unoNueve[j])) {
					miDNI += unoNueve[j];
				}
			}
		}
		if(miDNI.length() != 8) {//Devolvemos el DNI solo si su numero es diferente a 8
			return false;
		}else {
			return true;
		}
		
		
	}
	/**
	 * Constructor con parametros
	 * @param dni DNI de la Persona
	 * @return
	 */
	private static String letraDNI(String dni) {
			int miDNI = Integer.parseInt(dni.substring(0,8));
			int resto = 0;
			String miLetra = "";
			String[] asignacionLetra = {"T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C,","K","E"};
			
			resto = miDNI % 23;
			
			miLetra = asignacionLetra[resto];
			
			return miLetra;
		}
}
